

using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Device.Pwm;
using System.Device.Gpio;
using System.Threading;
using Iot.Device.Media;

using Iot.Device.ServoMotor;
using Iot.Device.Amg88xx;
using System.Device.I2c;
using UnitsNet;

using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Drawing;
using SixLabors.ImageSharp.PixelFormats;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Drawing.Processing;
using Gamepad;
using System.Formats.Tar;

//setting up the Amg88xx sensor


const int I2cBus = 1;
I2cConnectionSettings i2cSettings = new I2cConnectionSettings(I2cBus, Amg88xx.AlternativeI2cAddress);


GpioController ioController = new GpioController();

int joyud=0;
int joylr = 0;

int cautionlamp = 21;    
int headlamp = 20;
ioController.OpenPin(cautionlamp, PinMode.Output);
ioController.OpenPin(headlamp, PinMode.Output);
bool blinken = false;   
bool headlight = false;
var builder = WebApplication.CreateBuilder(args);
var pwm0 = PwmChannel.Create(0, 0, 400, 0.5);
var pwm1 = PwmChannel.Create(0, 1, 400, 0.5);

ServoMotor servoleft = new ServoMotor(
    pwm0,
    180,
    900,
    2100);
ServoMotor servoright = new ServoMotor(
    pwm1,
    180,
    900,
    2100);
servoleft.Start();
servoright.Start();
servoleft.WriteAngle(91);
servoright.WriteAngle(91);
// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();

bool invert = File.Exists("invert");

var app = builder.Build();
bool track = false;
// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}


app.UseStaticFiles();

app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");
Console.WriteLine("launching seperate thread for servo command stuff");

void facetrack()
{
    if (track==true)
    {
        //facetracking goes here

    }
    
}

void lampcontrol()
{
    do
    {
        if (blinken == true)
        {
            ioController.Write(cautionlamp, PinValue.High);
            Thread.Sleep(500);
            ioController.Write(cautionlamp, PinValue.Low);
        }
        if (headlight == true)
        {
            ioController.Write(headlamp, PinValue.High);
        }
        if (headlight == false)
        {
            ioController.Write(headlamp, PinValue.Low);
        }


    } while (true);
}



static float[,] InterpolateAMG88xxData(float[,] originalData, int newWidth, int newHeight)
{
    float[,] interpolatedData = new float[newHeight, newWidth];

    for (int y = 0; y < newHeight; y++)
    {
        for (int x = 0; x < newWidth; x++)
        {
            // Calculate the corresponding position in the original data
            float sourceX = x * originalData.GetLength(1) / (float)newWidth;
            float sourceY = y * originalData.GetLength(0) / (float)newHeight;

            // Perform linear interpolation to get the data value
            interpolatedData[y, x] = LinearInterpolate(originalData, sourceX, sourceY);
        }
    }

    return interpolatedData;
}
static float LinearInterpolate(float[,] data, float x, float y)
{
    int x0 = (int)x;
    int x1 = Math.Min(x0 + 1, data.GetLength(1) - 1);
    int y0 = (int)y;
    int y1 = Math.Min(y0 + 1, data.GetLength(0) - 1);

    float value00 = data[y0, x0];
    float value01 = data[y0, x1];
    float value10 = data[y1, x0];
    float value11 = data[y1, x1];

    float fx1 = x - x0;
    float fy1 = y - y0;

    return (1 - fx1) * (1 - fy1) * value00 + fx1 * (1 - fy1) * value01 +
           (1 - fx1) * fy1 * value10 + fx1 * fy1 * value11;
}

void thermalvision()
{
    try
    {
        //setup image output

        int width = Amg88xx.Width;
        int height = Amg88xx.Height;

        // Creates a new image with empty pixel data. 
        I2cDevice i2cDevice = I2cDevice.Create(i2cSettings);


        Amg88xx amg88xx = new Amg88xx(i2cDevice);
        // factory defaults
        amg88xx.Reset();
        amg88xx.OperatingMode = OperatingMode.Normal;
        Console.WriteLine($"Thermal Operating mode: {amg88xx.OperatingMode}");
        Console.WriteLine($"Average mode: {amg88xx.UseMovingAverageMode}");
        Console.WriteLine($"Frame rate: {amg88xx.FrameRate}");
        amg88xx.InterruptMode = InterruptMode.Absolute;
        amg88xx.InterruptPinEnabled = false;
        amg88xx.InterruptHysteresis = Temperature.FromDegreesCelsius(4);
        amg88xx.InterruptLowerLevel = Temperature.FromDegreesCelsius(10);
        amg88xx.InterruptUpperLevel = Temperature.FromDegreesCelsius(28);
        Console.WriteLine($"Interrupt mode: {amg88xx.InterruptMode}");
        Console.WriteLine($"Lower interrupt temperature level: {amg88xx.InterruptLowerLevel.DegreesCelsius:F1}�C");
        Console.WriteLine($"Upper interrupt temperature level: {amg88xx.InterruptUpperLevel.DegreesCelsius:F1}�C");
        Console.WriteLine($"Hysteresis level: {amg88xx.InterruptHysteresis.DegreesCelsius:F1}�C");




        while (true)
        {

            // Do your drawing in here...
            using Image image = new Image<Rgba32>(width * 10, height * 10);
            var interpolated = new Image<Rgba32>(640, 640);

            amg88xx.ReadImage();
            var intFlags = amg88xx.GetInterruptFlagTable();
            // Assuming you have an AMG88xx sensor data represented by a 2D array
            float[,] originalData = new float[8, 8];

            // Fill your original sensor data with temperature values or any other data

            // Create a new higher-resolution interpolated data
            //float[,] interpolatedData = InterpolateAMG88xxData(originalData, 16, 16);

            // Now, your 'interpolatedData' contains the result of interpolation

            // You can use or display the interpolated data as needed
            string thermalfiledata = "";
            for (int r = 7; r >= 0; r--)
            {
                for (int c = 7; c >= 0; c--)
                {


                    int pixelval = Convert.ToInt32(amg88xx[c, r].DegreesCelsius.ToString().Remove(2));
                    originalData[r, c] = pixelval;
                    //  Console.Write(pixelval + " ");
                    Rectangle bigpixel = new(c * 10, r * 10, 9, 9);

                    thermalfiledata = thermalfiledata + pixelval + ",";
                    pixelval = pixelval * 2;
                    if (pixelval > 255)
                    {
                        pixelval = 255;
                    }

                    image.Mutate(x => x.Draw(Color.FromRgb(Convert.ToByte(pixelval), 0, 0), 9, bigpixel));

                }
                // Console.WriteLine();

            }
            //  Console.WriteLine("\n----------------------------");
            float[,] interpolatedData = InterpolateAMG88xxData(originalData, interpolated.Width, interpolated.Height);
            //write interpolated output
            for (int A = 1; A < interpolated.Width; A++)
            {
                for (int B = 1; B < interpolated.Height; B++)
                {
                    Rgba32 newColor = new Rgba32(interpolatedData[A, B], 0, 0);
                    interpolated[A, B] = newColor;
                }
            }


            interpolated.SaveAsJpeg("interpolated.jpg");

            File.WriteAllText("thermal.txt", thermalfiledata);
            image.SaveAsBmp("thermal.bmp");
            image.SaveAsJpeg("thermal.jpg");
            image.Dispose();




            Thread.Sleep(100);


        }
    }
    catch { Console.WriteLine("thermal broke or not installed"); }
    }

static void HandleRequest(HttpListenerContext context)
{
    // Get the response object
    HttpListenerResponse response = context.Response;

    // Set the content type to JPEG
    response.ContentType = "image/jpeg";

    // Load the JPEG file content
    byte[] jpegBytes = File.ReadAllBytes("wwwroot/thermal.jpg");

    // Set the content length
    response.ContentLength64 = jpegBytes.Length;

    // Write the JPEG data to the response stream
    using (Stream output = response.OutputStream)
    {
        output.Write(jpegBytes, 0, jpegBytes.Length);
    }

    // Close the response stream
    response.Close();
}


void gamepadcontrol()
{

    try
    {
        Thread.Sleep(30000);
        blinken = false;
        headlight = true;
        int leftcomputed = 91;
        int rightcomputed = 91;
        var gamepad = new GamepadController("/dev/input/js0");

        // Configure this if you want to get events when the state of a button changes
        gamepad.ButtonChanged += (object sender, ButtonEventArgs e) =>
        {
            Console.WriteLine($"Button {e.Button} Pressed: {e.Pressed}");
        };

        gamepad.AxisChanged += (object sender, AxisEventArgs e) =>
        {
            //
            //Console.WriteLine($"Axis {e.Axis} Changed: {e.Value}");

            if (e.Axis.ToString() == "1")
            {

                joyud = e.Value;

            };
            if (e.Axis.ToString() == "0")
            {

                joylr = e.Value;

            };
            // Console.WriteLine("joyupdown:" + joyud + " joyleftright:" + joylr);

            // Configure this if you want to get events when the state of an axis changes




       

        };
    }
    catch
    {
        Console.WriteLine("no gamepad available!");
        
    }
    // Remember to Dispose the GamepadController, so it can finish the Task that listens
}
static void SendUdp(int srcPort, string dstIp, int dstPort, byte[] data)
{
    using (UdpClient c = new UdpClient(srcPort))
        c.Send(data, data.Length, dstIp, dstPort);
}
int itgo = 0;
void controlintroplocal()
{
    do
    {
        
        //local control
        if (joyud > 30000)
        {
            //forward
            SendUdp(11000, "localhost", 1245, Encoding.ASCII.GetBytes("reverse"));
            itgo = 1;
        }
        if (joyud < -30000)
        {
            //reverse
            SendUdp(11000, "localhost", 1245, Encoding.ASCII.GetBytes("forward"));
            itgo = 1;
        }
        if (joylr > 30000)
        {
            //left
            SendUdp(11000, "localhost", 1245, Encoding.ASCII.GetBytes("right"));
            itgo = 1;
        }
        if (joylr < -30000)
        {
            //right
            SendUdp(11000, "localhost", 1245, Encoding.ASCII.GetBytes("left"));
            itgo = 1;
        }
        if (joylr ==0 & joyud ==0)
        {
            //stop
            if (itgo == 1)
            {
                SendUdp(11000, "localhost", 1245, Encoding.ASCII.GetBytes("stop"));
                itgo = 0;
            }
        }
        Thread.Sleep(200);
    } while (true);

}


void mainthread()

{

    UdpClient receivingUdpClient = new UdpClient(1245);
    IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, 0);
    Console.WriteLine("pipbot command server");
    Console.WriteLine("listening for udp commands on 1245 ");
    int servo1 = 91;
    int servo2 = 91;
    blinken = true;
    do
    {
       


        try
        {

            // Blocks until a message returns on this socket from a remote host.
            Byte[] receiveBytes = receivingUdpClient.Receive(ref RemoteIpEndPoint);

            string returnData = Encoding.ASCII.GetString(receiveBytes);

            Console.WriteLine("This is the message you received " +
                                      returnData.ToString());
            Console.WriteLine("This message was sent from " +
                                        RemoteIpEndPoint.Address.ToString() +
                                        " on their port number " +
                                        RemoteIpEndPoint.Port.ToString());

            if(returnData.ToString()=="stop")
            {
                Console.WriteLine(returnData.ToString());
                servoleft.WriteAngle(91);
                servoright.WriteAngle(91);



            }
            if (returnData.ToString() == "forward")
            {
                Console.WriteLine(returnData.ToString());
                if (invert == false)
                {
                    servoleft.WriteAngle(180);
                    servoright.WriteAngle(1);
                }
                if (invert == true)
                {
                    servoleft.WriteAngle(1);
                    servoright.WriteAngle(180);
                }


            }
            if (returnData.ToString() == "reverse")
            {
                Console.WriteLine(returnData.ToString());

                if (invert == false)
                {
                    servoleft.WriteAngle(1);
                    servoright.WriteAngle(180);
                }
                if (invert == true)
                {
                    servoleft.WriteAngle(180);
                    servoright.WriteAngle(1);
                }



            }
            if (returnData.ToString() == "left")
            {
                Console.WriteLine(returnData.ToString());
                if (invert == false)
                {
                    servoleft.WriteAngle(180);
                    servoright.WriteAngle(180);
                }
                if (invert == true)
                {
                    servoleft.WriteAngle(1);
                    servoright.WriteAngle(1);

                }
            }
                if (returnData.ToString() == "right")
                {
                    Console.WriteLine(returnData.ToString());
                    if (invert == false)
                    {
                        servoleft.WriteAngle(1);
                        servoright.WriteAngle(1);
                    }
                    if (invert == true)
                    {
                        servoleft.WriteAngle(180);
                        servoright.WriteAngle(180);

                    }
                }
            if (returnData.ToString().Contains("varmode")==true)
            {
                Console.WriteLine(returnData.ToString());
                String parsetgt = returnData.ToString();
              
                string[] values = parsetgt.Split(',');
                servo1 = Int32.Parse(values[1]);
                servo2= Int32.Parse(values[2]);

                Console.WriteLine(servo1 + "|" + servo2);
                servoleft.WriteAngle(servo1);
                servoright.WriteAngle(servo2);
            }
            if (returnData.ToString() == "track")

            {
                if(track==false)
                {
                    track = true;
                    return;
                }
                if (track == true)
                {
                    track = false;
                    return;
                }
            }




            }
        catch (Exception e)
        {
            Console.WriteLine(e.ToString());
        }
    } while (true);
}


Thread main = new Thread(new ThreadStart(mainthread));
Thread thermal = new Thread(new ThreadStart(thermalvision));
Thread gamepad = new Thread(new ThreadStart(gamepadcontrol));
Thread localcontrol = new Thread(new ThreadStart(controlintroplocal));
Thread lamps = new Thread(new ThreadStart(lampcontrol));


main.Start();
thermal.Start();   
gamepad.Start();
lamps.Start(); 
localcontrol.Start();
app.Run();
